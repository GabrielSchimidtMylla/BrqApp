cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-whitelist": "1.3.0"
}
// BOTTOM OF METADATA
});